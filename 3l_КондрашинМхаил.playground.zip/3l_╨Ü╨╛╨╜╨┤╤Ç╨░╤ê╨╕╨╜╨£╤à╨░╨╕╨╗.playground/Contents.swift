import UIKit


//Урок 3

//1. Описать несколько структур – любой легковой автомобиль SportCar и любой грузовик TrunkCar.
//
//2. Структуры должны содержать марку авто, год выпуска, объем багажника/кузова, запущен ли двигатель, открыты ли окна, заполненный объем багажника.
//
//3. Описать перечисление с возможными действиями с автомобилем: запустить/заглушить двигатель, открыть/закрыть окна, погрузить/выгрузить из кузова/багажника груз определенного объема.
//
//4. Добавить в структуры метод с одним аргументом типа перечисления, который будет менять свойства структуры в зависимости от действия.
//
//5. Инициализировать несколько экземпляров структур. Применить к ним различные действия.
//
//6. Вывести значения свойств экземпляров в консоль.

struct sportCar {
    var weight: Int
    var color: String
    var brand: String
    var speed: Int
    var year: Int
    var trunkVolume: Int
    let engine: String
    let windows: String
    var filledTrunk: Int
    
    func description(){
        print("Sport Car have weight: \(weight) color: \(color), brand: \(brand), speed: \(speed), year: \(year), trunkVolume: \(trunkVolume), engine: \(engine), windows: \(windows), filledTrunk: \(filledTrunk)")
    }
    mutating func fillingTrunk (cargoWeight: Int){
    filledTrunk += cargoWeight
    }
}
struct truck {
    var weight: Int
    var color: String
    var brand: String
    var speed: Int
    var year: Int
    var trunkVolume: Int
    let engine: String
    let windows: String
    var filledTrunk: Int
}
var ferrari = sportCar(weight: 950, color: "red", brand: "Ferrari", speed: 300, year: 2021, trunkVolume: 200, engine: "Start", windows: "Open", filledTrunk: 50)
var kamaz = truck(weight: 5500, color: "White", brand: "KAMAZ", speed: 160, year: 2020, trunkVolume: 10000, engine: "Start", windows: "Closed", filledTrunk: 7000)

print(ferrari)
print(kamaz)

enum Action {
    case engineStart
    case engineStop
    case windowsOpen (String)
    case windowsClose (String)
    case trunkFull (String)
    case trunkEmpty (String)
    case trunkLoad (Int)
    case trunkUnload (Int)
    
}

var action = Action.engineStart("Start")
action = .engineStop
action = .engineStart
action = .trunkLoad(20)

switch action {
case .engineStop:
    print("Stop")
    case .engineStart:
        print ("Start")
        case .trunkEmpty:
            print("trunk Empty")
            case .trunkFull:
                print ("trunk full")
                case .trunkLoad:
                    print ("Trunk load")
//... и т.д.

default:
    break

}

ferrari.description()
ferrari.fillingTrunk(cargoWeight: 10)
ferrari.description()
