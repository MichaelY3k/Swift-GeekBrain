import UIKit

//Урок 4. Введение в ООП — объектно-ориентированное программирование
//1. Описать класс Car c общими свойствами автомобилей и пустым методом действия по аналогии с прошлым заданием.
//
//2. Описать пару его наследников trunkCar и sportСar. Подумать, какими отличительными свойствами обладают эти автомобили. Описать в каждом наследнике специфичные для него свойства.
//
//3. Взять из прошлого урока enum с действиями над автомобилем. Подумать, какие особенные действия имеет trunkCar, а какие – sportCar. Добавить эти действия в перечисление.
//
//4. В каждом подклассе переопределить метод действия с автомобилем в соответствии с его классом.
//
//5. Создать несколько объектов каждого класса. Применить к ним различные действия.
//
//6. Вывести значения свойств экземпляров в консоль.
class Auto {
    var brand: String
    var year: Int
    var trunkVolume: Int
    var engine: engineAct
    var windows: windowsAct
    var filledTrunk: trunkAct
    
    init(brand: String, year: Int, trunkVolume: Int, engine: engineAct, windows: windowsAct, filledTrunk: trunkAct) {
        self.brand = brand
        self.year = year
        self.trunkVolume = trunkVolume
        self.engine = engine
        self.windows = windows
        self.filledTrunk = filledTrunk
    }
    enum engineAct: String {
        case start = "Start"
        case stop = "Stop"
    }
    enum windowsAct: String {
        case open = "Open"
        case close = "Close"
    }
    enum trunkAct {
        case trunkFull (full: String)
        case trunkEmpty (empty: String)
        case trunkLoad (load: Double)
    }
    func actionEngine(actionEn: engineAct){
        switch actionEn {
        case .start:
            print (actionEn.rawValue)
        case .stop:
            print (actionEn.rawValue)
            }
        }
    func actionWindows(actionWin: windowsAct){
        switch actionWin {
        case .open:
            print (actionWin.rawValue)
        case .close:
            print (actionWin.rawValue)
        }
    }
    func description(){
        print("Car have brand: \(brand), year: \(year), trunkVolume: \(trunkVolume), engine: \(engine.rawValue), windows: \(windows.rawValue), filledTrunk: \(filledTrunk)")
        }
    }
class sportCar: Auto {
    var gear: gearAct
    
    init (gear: gearAct){
        self.gear = gear
        
    }
    enum gearAct: String{
        case on = "Sports mode ON"
        case off = "Sports mode OFF"
    }
    func sportsMode (actionGear: gearAct){
        switch actionGear {
        case .on:
            print (actionGear.rawValue)
        case .off:
            print (actionGear.rawValue)
        }
        func descrSport(){
            print("Car have brand: \(brand), year: \(year), trunkVolume: \(trunkVolume), engine: \(engine.rawValue), windows: \(windows.rawValue), filledTrunk: \(filledTrunk), \(actionGear.rawValue) ")
        }
    }
    }



var ferrari = sportCar(gear: <#T##sportCar.gearAct#>)
ferrari.actionEngine(actionEn: .start)
ferrari.actionWindows(actionWin: .open)
ferrari.actionGear(actionGear: .on)
ferrari.descrSport()

// Не разобрался, почему инициализатор в подклассе ругается
