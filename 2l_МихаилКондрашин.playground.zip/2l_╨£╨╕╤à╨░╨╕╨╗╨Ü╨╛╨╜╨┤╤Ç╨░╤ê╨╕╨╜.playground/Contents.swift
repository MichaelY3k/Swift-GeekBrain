import UIKit

// 1. Написать функцию, которая определяет, четное число или нет.



func evenNumber (enterNumber a:Int){
        if a % 2 == 0 {
        print("Число четное")
    }
        else {
            print("Число не четное")
    }
}
evenNumber(enterNumber: 23)






// 2. Написать функцию, котороя определяет, делится ли число без остатка на 3

func remnant(enterNumber a:Int){
    if a % 3 == 0 {
        print("Число \(a) делится на 3 без остатка")
    } else {
        print("Число \(a) делится на 3 с остатком")
    }
}

remnant(enterNumber: 6)






// 3. Создать возрастающий массив из 100 чисел.


var arrNumbers:[Int]=[]
for i in 1 ... 100{
    arrNumbers.append(i)
}
print(arrNumbers)

// Еще нашел интересный вариант создания массива всего в 2 строки:
// var numbers = Array (1...100)
// print(numbers)





// 4. Удалить из этого массива все четные числа и все числа, которые не делятся на 3.


var filteredArrNums = arrNumbers.filter({$0 % 2 > 0})
print(filteredArrNums)

var filteredArrNums3 = arrNumbers.filter({$0 % 3 == 0})
print(filteredArrNums3)





